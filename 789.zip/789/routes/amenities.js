import express from "express";
import {
  getAllAmenities,
  createAmenity,
  getAmenityById,
  updateAmenity,
  deleteAmenity,
} from "../services/amenityService.js";
import { authenticate } from "../middleware/authMiddleware.js";

const router = express.Router();

router.get("/", getAllAmenities);
router.post("/", authenticate, createAmenity);
router.get("/:id", getAmenityById);
router.put("/:id", authenticate, updateAmenity);
router.delete("/:id", authenticate, deleteAmenity);

export default router;
