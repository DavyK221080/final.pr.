import express from "express";
import { authenticate } from "../middleware/authMiddleware.js";
import {
  getAllBookings,
  createBooking,
  getBookingById,
  updateBooking,
  deleteBooking,
} from "../services/bookingService.js";

const router = express.Router();

router.get("/", getAllBookings);
router.post("/", authenticate, createBooking);
router.put("/:id", authenticate, updateBooking);
router.delete("/:id", authenticate, deleteBooking);
router.get("/:id", getBookingById);

export default router;
