import express from "express";
import { authenticate } from "../middleware/authMiddleware.js";
import {
  createHost,
  getHostById,
  updateHost,
  deleteHost,
  getAllHosts,
} from "../services/hostService.js";

const router = express.Router();

router.post("/", authenticate, createHost);
router.put("/:id", authenticate, updateHost);
router.delete("/:id", authenticate, deleteHost);
router.get("/", getAllHosts);
router.get("/:id", getHostById);

export default router;
