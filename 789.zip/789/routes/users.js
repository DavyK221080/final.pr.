import express from "express";
import { authenticate } from "../middleware/authMiddleware.js";
import {
  createUser,
  getUserById,
  updateUser,
  deleteUser,
  getAllUsers,
} from "../services/userService.js";

const router = express.Router();

router.post("/", authenticate, createUser);
router.put("/:id", authenticate, updateUser);
router.delete("/:id", authenticate, deleteUser);
router.get("/", getAllUsers);
router.get("/:id", getUserById);

export default router;
