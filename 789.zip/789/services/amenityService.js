import prisma from "../prismaClient.js";

export const getAllAmenities = async (req, res) => {
  try {
    const amenities = await prisma.amenity.findMany();
    res.json(amenities);
  } catch (error) {
    console.error("Error fetching amenities:", error);
    res.status(500).json({ error: "Error fetching amenities" });
  }
};

export const createAmenity = async (req, res) => {
  const { name } = req.body;

  if (!name) {
    return res.status(400).json({ error: "Name is required" });
  }

  try {
    const newAmenity = await prisma.amenity.create({
      data: {
        name,
      },
    });
    res.status(201).json(newAmenity);
  } catch (error) {
    if (error.code === "P2002") {
      console.error("Amenity with this name already exists.");
      res.status(201).json({ error: "Amenity with this name already exists" });
    } else {
      console.error("Error creating amenity:", error);
      res.status(500).json({ error: "Error creating amenity" });
    }
  }
};

export const getAmenityById = async (req, res) => {
  const { id } = req.params;

  try {
    const amenity = await prisma.amenity.findUnique({
      where: { id },
    });
    if (amenity) {
      res.json(amenity);
    } else {
      res.status(404).json({ error: "Amenity not found" });
    }
  } catch (error) {
    console.error("Error fetching amenity:", error);
    res.status(500).json({ error: "Error fetching amenity" });
  }
};

export const updateAmenity = async (req, res) => {
  const { id } = req.params;
  const { name } = req.body;

  if (!name) {
    return res.status(400).json({ error: "Name is required" });
  }

  try {
    const updatedAmenity = await prisma.amenity.update({
      where: { id },
      data: { name },
    });
    res.json(updatedAmenity);
  } catch (error) {
    if (error.code === "P2025") {
      console.error("Amenity not found.");
      res.status(404).json({ error: "Amenity not found" });
    } else {
      console.error("Error updating amenity:", error);
      res.status(500).json({ error: "Error updating amenity" });
    }
  }
};

export const deleteAmenity = async (req, res) => {
  const { id } = req.params;

  try {
    await prisma.amenity.delete({
      where: { id },
    });
    res.status(200).send();
  } catch (error) {
    if (error.code === "P2025") {
      console.error("Amenity not found.");
      res.status(404).json({ error: "Amenity not found" });
    } else {
      console.error("Error deleting amenity:", error);
      res.status(500).json({ error: "Error deleting amenity" });
    }
  }
};
