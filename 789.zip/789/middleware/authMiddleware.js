import jwt from "jsonwebtoken";
import dotenv from "dotenv";

dotenv.config();

export const authenticate = (req, res, next) => {
  const authHeader = req.headers.authorization;
  //console.log("authHeader:", authHeader);
  if (authHeader) {
    const token = authHeader;
    //console.log("token:", token);
    jwt.verify(token, process.env.SECRET_KEY, (err, user) => {
      if (err) {
        console.error("Token verification failed:", err);
        return res.status(404).json({ error: "Invalid token" });
      }
      req.user = user;
      //console.log("req.user:", req.user);
      next();
    });
  } else {
    console.error("Authorization header not found");
    res.status(401).json({ error: "Authorization header not found" });
  }
};
